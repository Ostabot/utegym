
/** Minimal extracted types from your supabase.types.ts for quick start.
 * Replace with a generated file later.
 */
export type Gyms = {
  id: string;
  name: string;
  city: string | null;
  lat: number;
  lon: number;
  address: string | null;
  image_url: string | null;
};
export type Workouts = {
  id: string;
  user_id: string;
  started_at: string;
  ended_at: string | null;
  gym_id: string | null;
};
export type Photos = {
  id: number;
  gym_id: string | null;
  name: string | null;
};
// Helper generic for Table Row inference (swap to full generated types when available)
export type Tables<T extends 'gyms' | 'workouts' | 'photos'> =
  T extends 'gyms' ? Gyms :
  T extends 'workouts' ? Workouts :
  T extends 'photos' ? Photos : never;
